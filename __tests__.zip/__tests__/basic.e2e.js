import wd from 'wd';


import 'react-native';
import React from 'react';
import App from '../App';
import SignIn from '../screens/SignIn';
import chai from 'chai';

// Note: test renderer must be required after react-native.
import renderer from 'react-test-renderer';
jest.mock('react-native-camera', () => 'Camera');
jest.mock('@haskkor/react-native-pincode', () => 'PinCode');
// jest.mock('react-navigation', () => 'DrawerNavigator');
// jest.mock('react-native-camera', () => require.requireActual('../__mocks__/react-native-camera').default())

jasmine.DEFAULT_TIMEOUT_INTERVAL = 60000;
const PORT = 4723;
const config = {
  platformName: 'Android',
  deviceName: 'Android Emulator',
  appPackage: 'com.theqrl',
  appActivity: 'MainActivity',
  app: '/Users/abilican/Documents/projects/perso/theqrl/RNapp/theQRL/android/app/build/outputs/apk/release/qrlwallet-1.0.7.apk'
};
// const driver = wd.promiseChainRemote('localhost', PORT);


// for AWS Device Farm testing
const driver = wd.promiseChainRemote('lhttp://localhost:4723/wd/hub');


beforeAll(async () => {
  // await driver.init(config);
  await driver.sleep(2000); // wait for app to load
})


afterAll(async () => {
  try {
    await driver.quit();
  }
  catch(err) {
    console.error(err);
  }
});


test('appium renders', async () => {
  expect(await driver.hasElementByAccessibilityId('notthere')).toBe(false);
  // expect(await driver.hasElementByAccessibilityId('testview')).toBe(true);
});



// test('renders correctly', () => {
//   const tree = renderer.create(
//     <App />
//   );
// });

// test('renders Create wallet', () => {
//   const tree = renderer.create(
//     <SignIn />
//   );
// });

test('has correct create wallet button', async () => {
  // expect(await driver.hasElementByAccessibilityId('notthere')).toBe(false);
  // let contexts = await driver.contexts();
  // console.log(contexts)
  // await driver.context(contexts[1]);
  expect(await driver.hasElementByAccessibilityId('SignIn')).toBe(true);
  expect(await driver.hasElementByAccessibilityId('test')).toBe(true);
});


// const wdio = require("webdriverio");

// const opts = {
//   port: 4723,
//   capabilities: {
//     platformName: "Android",
//     platformVersion: "8.0",
//     deviceName: "Pixel_2_API_27",
//     app: "/Users/abilican/Documents/projects/perso/theqrl/RNapp/theQRL/android/app/build/outputs/apk/release/qrlwallet-1.0.7.apk",
//     automationName: "UiAutomator2"
//   }
// };

// const client = wdio.remote(opts);
// // client.sleep(000);

// // const elementId = await client.findElement("accessibility id","testview");
// // await client.elementSendKeys(elementId.ELEMENT, "Hello World!");
// // const elementValue = await client.findElement("accessibility id","TextField1");
// // await client.getElementAttribute(elementValue.ELEMENT,"value").then((attr) => {
// //   assert.equal(attr,"Hello World!");
// // });


// link = client.find_element_by_xpath('//*[@text="CREATE DEFAULT WALLET"]')
// link.click()

// // test('appium renders', async () => {
// //   // expect(await client.findElement("accessibility id",'testview')).toBe(true);
// //   expect(await driver.hasElementByAccessibilityId('notthere')).toBe(false);
// //   expect(await driver.hasElementByAccessibilityId('testview')).toBe(true);
// // });

// client.quit()